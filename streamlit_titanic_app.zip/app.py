
import streamlit as st
import pandas as pd
import pickle

# Load model
model = pickle.load(open('logistic_model.pkl', 'rb'))

st.title("Titanic Survival Prediction App")

# Inputs
Pclass = st.selectbox('Passenger Class (1 = 1st, 2 = 2nd, 3 = 3rd)', [1, 2, 3])
Sex = st.selectbox('Sex', ['male', 'female'])
Age = st.slider('Age', 0, 100, 30)
SibSp = st.slider('Number of Siblings/Spouses aboard', 0, 10, 0)
Parch = st.slider('Number of Parents/Children aboard', 0, 10, 0)
Fare = st.number_input('Fare', 0.0, 500.0, 30.0)
Embarked = st.selectbox('Port of Embarkation', ['S', 'C', 'Q'])

# Encoding
sex = 0 if Sex == 'male' else 1
embarked_dict = {'S': 2, 'C': 0, 'Q': 1}
embarked = embarked_dict[Embarked]

# Predict
if st.button("Predict"):
    input_data = pd.DataFrame([[Pclass, sex, Age, SibSp, Parch, Fare, embarked]],
                              columns=['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked'])
    result = model.predict(input_data)[0]
    st.success("Survived" if result == 1 else "Did Not Survive")
